local frame = CreateFrame("Frame", "WPT_Frame", UIParent)

-- =========================================================
-- BASE FRAME
-- =========================================================
local BASE_WIDTH = 1366
local BASE_HEIGHT = 1031
local DEFAULT_SCALE = 0.38
local MIN_SCALE = 0.22
local MAX_SCALE = 0.80

local BS_FULL_X,  BS_FULL_Y  = 210, -300
local MIN_FULL_X, MIN_FULL_Y = 420, -300

local BS_MIN_X,   BS_MIN_Y   = 200, -290
local MIN_MIN_X,  MIN_MIN_Y  = 400, -290

frame:SetSize(BASE_WIDTH, BASE_HEIGHT)

WowProfTrackerDB = WowProfTrackerDB or {}
local savedScale = WowProfTrackerDB.scale or DEFAULT_SCALE
if savedScale < MIN_SCALE then savedScale = MIN_SCALE end
if savedScale > MAX_SCALE then savedScale = MAX_SCALE end

frame:SetScale(savedScale)
frame:ClearAllPoints()
frame:SetPoint("TOPLEFT", UIParent, "TOPLEFT", 120, -120)

frame:SetMovable(true)
frame:EnableMouse(true)
frame:RegisterForDrag("LeftButton")
frame:SetClampedToScreen(true)
frame:SetScript("OnDragStart", function(self)
    if self.isResizing then return end
    self:StartMoving()
end)
frame:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()

    WowProfTrackerDB = WowProfTrackerDB or {}
    local point, _, _, x, y = self:GetPoint()
    WowProfTrackerDB.pos = { point = point, x = x, y = y }
end)

if WowProfTrackerDB and WowProfTrackerDB.pos then
    local p = WowProfTrackerDB.pos
    frame:ClearAllPoints()
    frame:SetPoint(p.point, UIParent, p.point, p.x, p.y)
end

frame.bg = frame:CreateTexture(nil, "BACKGROUND")
frame.bg:SetAllPoints()
frame.bg:SetTexture("Interface\\AddOns\\WowProfTracker\\Media\\UI.tga")

-- =========================================================
-- FONT HELPERS
-- =========================================================
local function CreateText(layer, font, size, outline, r, g, b, justifyH)
    local fs = frame:CreateFontString(nil, layer or "OVERLAY")
    fs:SetFont(font or "Fonts\\FRIZQT__.TTF", size or 14, outline or "")
    fs:SetTextColor(r or 1, g or 1, b or 1, 1)
    fs:SetJustifyH(justifyH or "LEFT")
    fs:SetJustifyV("MIDDLE")
    return fs
end

local goldFont   = "Fonts\\MORPHEUS.TTF"
local normalFont = "Fonts\\FRIZQT__.TTF"
local numberFont = "Fonts\\ARIALN.TTF"

-- =========================================================
-- DATA
-- =========================================================
local recipes = {
    { min = 57,  max = 65,  name = "Rough Grinding Stone",     mats = { roughStone = 2 } },
    { min = 65,  max = 75,  name = "Coarse Sharpening Stone",  mats = { coarseStone = 1 } },
    { min = 75,  max = 90,  name = "Coarse Grinding Stone",    mats = { coarseStone = 2 } },
    { min = 90,  max = 100, name = "Runed Copper Belt",        mats = { copperBars = 10 } },
    { min = 100, max = 125, name = "Rough Bronze Leggings",    mats = { bronzeBars = 6 } },
    { min = 125, max = 140, name = "Heavy Grinding Stone",     mats = { heavyStone = 3 } },
    { min = 140, max = 150, name = "Patterned Bronze Bracers", mats = { bronzeBars = 6 } },
    { min = 150, max = 165, name = "Green Iron Leggings",      mats = { ironBars = 8 } },
    { min = 165, max = 190, name = "Green Iron Bracers",       mats = { ironBars = 6 } },
    { min = 190, max = 200, name = "Golden Scale Bracers",     mats = { steelBars = 4 } },
    { min = 200, max = 210, name = "Solid Grinding Stone",     mats = { solidStone = 4 } },
    { min = 210, max = 225, name = "Heavy Mithril Gauntlet",   mats = { mithrilBars = 12 } },
    { min = 225, max = 235, name = "Steel Plate Helm",         mats = { steelBars = 12 } },
    { min = 235, max = 250, name = "Mithril Coif",             mats = { mithrilBars = 14 } },
    { min = 250, max = 260, name = "Dense Sharpening Stone",   mats = { denseStone = 4 } },
    { min = 260, max = 270, name = "Thorium Belt",             mats = { thoriumBars = 6 } },
    { min = 270, max = 275, name = "Thorium Bracers",          mats = { thoriumBars = 8 } },
    { min = 275, max = 290, name = "Imperial Plate Bracers",   mats = { thoriumBars = 12 } },
    { min = 290, max = 300, name = "Thorium Boots",            mats = { thoriumBars = 16 } },
}

local materialLabels = {
    copperOre     = "Copper Ore",
    tinOre        = "Tin Ore",
    silverOre     = "Silver Ore",
    ironOre       = "Iron Ore",
    goldOre       = "Gold Ore",
    mithrilOre    = "Mithril Ore",
    truesilverOre = "Truesilver Ore",
    thoriumOre    = "Thorium Ore",

    copperBars    = "Copper Bar",
    tinBars       = "Tin Bar",
    bronzeBars    = "Bronze Bar",
    ironBars      = "Iron Bar",
    steelBars     = "Steel Bar",
    mithrilBars   = "Mithril Bar",
    thoriumBars   = "Thorium Bar",

    roughStone    = "Rough Stone",
    coarseStone   = "Coarse Stone",
    heavyStone    = "Heavy Stone",
    solidStone    = "Solid Stone",
    denseStone    = "Dense Stone",
}

local leftMaterials = {
    "copperOre", "tinOre", "silverOre", "ironOre",
    "goldOre", "mithrilOre", "truesilverOre", "thoriumOre"
}

local rightMaterials = {
    "copperBars", "tinBars", "bronzeBars", "ironBars", "steelBars",
    "mithrilBars", "thoriumBars", "roughStone", "coarseStone",
    "heavyStone", "solidStone", "denseStone"
}

-- =========================================================
-- HELPERS
-- =========================================================
local function Clamp(v, minVal, maxVal)
    if v < minVal then return minVal end
    if v > maxVal then return maxVal end
    return v
end

local function GetCurrentRecipe()
    local bs = (WowProfTrackerDB and WowProfTrackerDB.bs) or 0
    for _, recipe in ipairs(recipes) do
        if bs >= recipe.min and bs < recipe.max then
            return recipe
        end
    end
    return nil
end

local function GetMatCount(key)
    local mats = (WowProfTrackerDB and WowProfTrackerDB.mats) or {}
    return mats[key] or 0
end

local function GetAvailableCount(key)
    local count = GetMatCount(key)
    local bars = GetBarEstimate and GetBarEstimate() or nil

    if bars then
        if key == "copperBars" then return bars.copperBars or count end
        if key == "tinBars" then return bars.tinBars or count end
        if key == "ironBars" then return bars.ironBars or count end
        if key == "mithrilBars" then return bars.mithrilBars or count end
        if key == "thoriumBars" then return bars.thoriumBars or count end
    end

    return count
end

local function GetMaxCraftable(recipe)
    if not recipe then return 0 end

    local maxCrafts = nil
    for key, needed in pairs(recipe.mats) do
        local available = GetAvailableCount(key)
        local canMake = math.floor(available / needed)

        if maxCrafts == nil or canMake < maxCrafts then
            maxCrafts = canMake
        end
    end

    return maxCrafts or 0
end

local function GetPrimarySecondaryMats(recipe)
    if not recipe then return nil, nil end

    local ordered = {}
    for key, needed in pairs(recipe.mats) do
        ordered[#ordered + 1] = { key = key, needed = needed }
    end

    table.sort(ordered, function(a, b)
        return (materialLabels[a.key] or a.key) < (materialLabels[b.key] or b.key)
    end)

    return ordered[1], ordered[2]
end

local function CountTotalMats()
    local mats = (WowProfTrackerDB and WowProfTrackerDB.mats) or {}
    local total = 0
    for _, v in pairs(mats) do
        total = total + (v or 0)
    end
    return total
end

-- =========================================================
-- PULSE / GLOW
-- =========================================================
local pulseTargets = {}

local function AddPulseTarget(region, baseScale, maxScale, alphaMin, alphaMax, speed)
    pulseTargets[region] = {
        baseScale = baseScale or 1.0,
        maxScale = maxScale or 1.08,
        alphaMin = alphaMin or 0.75,
        alphaMax = alphaMax or 1.0,
        speed = speed or 2.5,
        active = false
    }
    region:SetScale(baseScale or 1.0)
    region:SetAlpha(alphaMax or 1.0)
end

local function SetPulse(region, enabled)
    local cfg = pulseTargets[region]
    if not cfg then return end
    cfg.active = enabled and true or false

    if not cfg.active then
        region:SetScale(cfg.baseScale)
        region:SetAlpha(cfg.alphaMax)
    end
end

frame.pulseDriver = CreateFrame("Frame", nil, frame)
frame.pulseDriver:SetScript("OnUpdate", function()
    for region, cfg in pairs(pulseTargets) do
        if cfg.active and region:IsShown() then
            local t = GetTime() * cfg.speed
            local wave = (math.sin(t) + 1) / 2
            local scale = cfg.baseScale + ((cfg.maxScale - cfg.baseScale) * wave)
            local alpha = cfg.alphaMin + ((cfg.alphaMax - cfg.alphaMin) * wave)
            region:SetScale(scale)
            region:SetAlpha(alpha)
        end
    end
end)

local function CreateSoftGlow(parent, width, height, x, y)
    local tex = parent:CreateTexture(nil, "ARTWORK", nil, 2)
    tex:SetTexture("Interface\\Buttons\\WHITE8X8")
    tex:SetBlendMode("ADD")
    tex:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    tex:SetSize(width, height)
    tex:SetColorTexture(0.2, 1.0, 0.2, 0.0)
    tex:Hide()
    return tex
end

local function SetGlow(tex, show, r, g, b, a)
    if show then
        tex:SetColorTexture(r or 0.2, g or 1.0, b or 0.2, a or 0.18)
        tex:Show()
    else
        tex:Hide()
    end
end

local function PositionSkillNumbers(minimized)
    frame.bsText:ClearAllPoints()
    frame.minText:ClearAllPoints()

    if minimized then
        frame.bsText:SetPoint("CENTER", frame, "TOPLEFT", BS_MIN_X, BS_MIN_Y)
        frame.minText:SetPoint("CENTER", frame, "TOPLEFT", MIN_MIN_X, MIN_MIN_Y)
    else
        frame.bsText:SetPoint("CENTER", frame, "TOPLEFT", BS_FULL_X, BS_FULL_Y)
        frame.minText:SetPoint("CENTER", frame, "TOPLEFT", MIN_FULL_X, MIN_FULL_Y)
    end
end

-- =========================================================
-- HEADER / SKILLS
-- =========================================================
frame.title = CreateText("OVERLAY", goldFont, 40, "OUTLINE", 0.96, 0.78, 0.20, "CENTER")
frame.title:SetText("")

frame.bsText = CreateText("OVERLAY", numberFont, 46, "OUTLINE", 0.95, 0.82, 0.20, "CENTER")

frame.bsLabel = CreateText("OVERLAY", normalFont, 18, "OUTLINE", 1, 1, 1, "CENTER")
frame.bsLabel:SetPoint("CENTER", frame, "TOPLEFT", 245, -408)
frame.bsLabel:SetText("")

frame.minText = CreateText("OVERLAY", numberFont, 46, "OUTLINE", 0.30, 0.95, 0.30, "CENTER")

frame.minLabel = CreateText("OVERLAY", normalFont, 18, "OUTLINE", 1, 1, 1, "CENTER")
frame.minLabel:SetPoint("CENTER", frame, "TOPLEFT", 455, -408)
frame.minLabel:SetText("")

PositionSkillNumbers(false)

AddPulseTarget(frame.bsText, 1.0, 1.08, 0.85, 1.0, 2.6)
AddPulseTarget(frame.minText, 1.0, 1.08, 0.85, 1.0, 2.6)

-- =========================================================
-- TOP BAR TEXT
-- =========================================================
frame.topMat1Label = CreateText("OVERLAY", normalFont, 26, "OUTLINE", 1, 1, 1)
frame.topMat1Label:SetPoint("TOPLEFT", frame, "TOPLEFT", 575, -150)

frame.topMat1Value = CreateText("OVERLAY", numberFont, 28, "OUTLINE", 1, 0.35, 0.35, "RIGHT")
frame.topMat1Value:SetPoint("TOPRIGHT", frame, "TOPLEFT", 1245, -150)

frame.topMat2Label = CreateText("OVERLAY", normalFont, 26, "OUTLINE", 1, 1, 1)
frame.topMat2Label:SetPoint("TOPLEFT", frame, "TOPLEFT", 575, -322)

frame.topMat2Value = CreateText("OVERLAY", numberFont, 28, "OUTLINE", 0.95, 0.82, 0.20, "RIGHT")
frame.topMat2Value:SetPoint("TOPRIGHT", frame, "TOPLEFT", 1245, -322)

frame.nextCraft = CreateText("OVERLAY", normalFont, 28, "OUTLINE", 0.96, 0.78, 0.20, "CENTER")
frame.nextCraft:SetPoint("CENTER", frame, "TOPLEFT", 910, -373)

frame.nextRange = CreateText("OVERLAY", normalFont, 22, "OUTLINE", 0.85, 0.85, 0.85, "LEFT")
frame.nextRange:SetPoint("LEFT", frame.nextCraft, "RIGHT", 10, 0)

AddPulseTarget(frame.nextCraft, 1.0, 1.05, 0.90, 1.0, 2.2)

-- =========================================================
-- BARS
-- =========================================================
local function CreateOverlayBar(width, height, x, y, barType)
    local bar = CreateFrame("StatusBar", nil, frame)
    bar:SetSize(width, height)
    bar:SetPoint("TOPLEFT", frame, "TOPLEFT", x, y)
    bar:SetMinMaxValues(0, 1)
    bar:SetValue(0)
    bar.currentValue = 0
    bar:SetStatusBarTexture("Interface\\TargetingFrame\\UI-StatusBar")
    bar:SetFrameLevel(frame:GetFrameLevel() + 5)

    local bg = bar:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0, 0, 0, 0.20)

    local glow = bar:CreateTexture(nil, "ARTWORK", nil, 1)
    glow:SetTexture("Interface\\TargetingFrame\\UI-StatusBar")
    glow:SetBlendMode("ADD")
    glow:SetAlpha(0.18)
    glow:SetAllPoints(bar)
    bar.innerGlow = glow

    bar.outerGlow = CreateSoftGlow(frame, width + 8, height + 8, x - 4, y + 4)
    bar.barType = barType
    return bar
end

local function AnimateBar(bar, targetValue)
    targetValue = Clamp(targetValue or 0, 0, 1)
    bar.targetValue = targetValue

    if not bar.animating then
        bar.animating = true
        bar:SetScript("OnUpdate", function(self, elapsed)
            local current = self.currentValue or 0
            local target = self.targetValue or 0
            local speed = 3.5

            if math.abs(current - target) < 0.005 then
                current = target
                self.currentValue = current
                self:SetValue(current)
                self.animating = false
                self:SetScript("OnUpdate", nil)
                return
            end

            current = current + (target - current) * math.min(elapsed * speed, 1)
            self.currentValue = current
            self:SetValue(current)
        end)
    end
end

local function SetBarColorByPercent(bar, pct, barType)
    if barType == "health" then
        if pct >= 1 then
            bar:SetStatusBarColor(0.20, 0.85, 0.20)
            bar.innerGlow:SetVertexColor(0.20, 0.85, 0.20)
        elseif pct >= 0.5 then
            bar:SetStatusBarColor(0.90, 0.75, 0.10)
            bar.innerGlow:SetVertexColor(0.90, 0.75, 0.10)
        else
            bar:SetStatusBarColor(0.75, 0.10, 0.10)
            bar.innerGlow:SetVertexColor(0.75, 0.10, 0.10)
        end
    else
        if pct >= 1 then
            bar:SetStatusBarColor(0.20, 0.85, 0.20)
            bar.innerGlow:SetVertexColor(0.20, 0.85, 0.20)
        elseif pct >= 0.5 then
            bar:SetStatusBarColor(0.90, 0.75, 0.10)
            bar.innerGlow:SetVertexColor(0.90, 0.75, 0.10)
        else
            bar:SetStatusBarColor(0.85, 0.55, 0.10)
            bar.innerGlow:SetVertexColor(0.85, 0.55, 0.10)
        end
    end
end

frame.healthBar = CreateOverlayBar(720, 24, 565, -200, "health")
frame.manaBar   = CreateOverlayBar(720, 24, 565, -329, "mana")

-- =========================================================
-- BOTTOM VALUES ONLY
-- =========================================================
frame.zoneText = CreateText("OVERLAY", normalFont, 22, "OUTLINE", 1, 1, 1, "LEFT")
frame.zoneText:SetPoint("TOPLEFT", frame, "TOPLEFT", 142, -475)
frame.zoneText:SetText("")

frame.barsFromOreText = CreateText("OVERLAY", normalFont, 18, "OUTLINE", 1, 1, 1, "LEFT")
frame.barsFromOreText:SetPoint("TOPLEFT", frame, "TOPLEFT", 482, -475)
frame.barsFromOreText:SetText("")

frame.canCraftText = CreateText("OVERLAY", numberFont, 28, "OUTLINE", 1, 0.20, 0.20, "LEFT")
frame.canCraftText:SetPoint("TOPLEFT", frame, "TOPLEFT", 792, -475)
frame.canCraftText:SetText("")

frame.totalText = CreateText("OVERLAY", normalFont, 22, "OUTLINE", 1, 1, 1, "LEFT")
frame.totalText:SetPoint("TOPLEFT", frame, "TOPLEFT", 1100, -475)
frame.totalText:SetText("")

AddPulseTarget(frame.canCraftText, 1.0, 1.10, 0.80, 1.0, 3.0)

frame.commandText = CreateText("OVERLAY", goldFont, 22, "OUTLINE", 0.96, 0.78, 0.20, "CENTER")
frame.commandText:SetPoint("CENTER", frame, "BOTTOM", 0, 38)
frame.commandText:SetText("/WPT TOGGLE   •   /WPT REFRESH   •   /WPT RESET")

-- =========================================================
-- MATERIAL LISTS
-- =========================================================
frame.leftRows = {}
frame.rightRows = {}

local function CreateMatRow(xLabel, xValue, y)
    local label = CreateText("OVERLAY", normalFont, 18, "OUTLINE", 1, 1, 1)
    label:SetPoint("TOPLEFT", frame, "TOPLEFT", xLabel, y)

    local value = CreateText("OVERLAY", numberFont, 18, "OUTLINE", 0.30, 0.95, 0.30, "RIGHT")
    value:SetPoint("TOPLEFT", frame, "TOPLEFT", xValue, y)

    return { label = label, value = value }
end

local yStartLeft = -540
for i = 1, #leftMaterials do
    frame.leftRows[i] = CreateMatRow(135, 515, yStartLeft - ((i - 1) * 45))
end

local yStartRight = -540
for i = 1, #rightMaterials do
    frame.rightRows[i] = CreateMatRow(775, 1220, yStartRight - ((i - 1) * 35))
end

-- =========================================================
-- VISIBILITY HELPERS FOR MINIMIZE
-- =========================================================
local function SetRegionVisible(region, visible)
    if not region then return end
    if visible then region:Show() else region:Hide() end
end

local function SetChildrenVisible(visible)
    local children = {
        frame.bsLabel,
        frame.minLabel,
        frame.topMat1Label, frame.topMat1Value,
        frame.topMat2Label, frame.topMat2Value,
        frame.nextCraft, frame.nextRange,
        frame.healthBar, frame.manaBar,
        frame.zoneText, frame.barsFromOreText,
        frame.canCraftText, frame.totalText,
        frame.commandText,
        frame.refreshButton,
        frame.resizeHandle
    }

    for _, child in ipairs(children) do
        SetRegionVisible(child, visible)
    end

    if frame.leftRows then
        for _, row in ipairs(frame.leftRows) do
            SetRegionVisible(row.label, visible)
            SetRegionVisible(row.value, visible)
        end
    end

    if frame.rightRows then
        for _, row in ipairs(frame.rightRows) do
            SetRegionVisible(row.label, visible)
            SetRegionVisible(row.value, visible)
        end
    end
end

local function SetMinimized(minimized)
    WowProfTrackerDB = WowProfTrackerDB or {}
    WowProfTrackerDB.minimized = minimized and true or false

	if minimized then
		frame:SetSize(500, 430)
		frame.bg:SetTexCoord(0.00, 0.38, 0.00, 0.43)
		PositionSkillNumbers(true)

		SetChildrenVisible(false)
		frame.bsText:Show()
		frame.minText:Show()

		if frame.closeButton then frame.closeButton:Hide() end
		if frame.minimizedClickButton then frame.minimizedClickButton:Show() end
    else
		frame:SetSize(BASE_WIDTH, BASE_HEIGHT)
		frame.bg:SetTexCoord(0, 1, 0, 1)
		PositionSkillNumbers(false)

        if frame.minimizedClickButton then frame.minimizedClickButton:Hide() end
        if frame.closeButton then frame.closeButton:Show() end

        SetChildrenVisible(true)

        if WowProfTracker_UpdateUI then
            WowProfTracker_UpdateUI()
        end
    end
end

-- =========================================================
-- BUTTON HOTSPOTS
-- =========================================================
frame.refreshButton = CreateFrame("Button", nil, frame)
frame.refreshButton:SetSize(140, 50)
frame.refreshButton:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -70, -120)
frame.refreshButton:SetScript("OnClick", function()
    if WowProfTracker_RefreshAll then
        WowProfTracker_RefreshAll(true)
    end
end)

frame.closeButton = CreateFrame("Button", nil, frame)
frame.closeButton:SetSize(120, 120)
frame.closeButton:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -65, -70)
frame.closeButton:SetScript("OnClick", function()
    SetMinimized(not (WowProfTrackerDB and WowProfTrackerDB.minimized))
end)

frame.minimizedClickButton = CreateFrame("Button", nil, frame)
frame.minimizedClickButton:SetAllPoints(frame)
frame.minimizedClickButton:SetScript("OnClick", function()
    if WowProfTrackerDB and WowProfTrackerDB.minimized then
        SetMinimized(false)
    end
end)
frame.minimizedClickButton:Hide()

-- =========================================================
-- RESIZE HANDLE
-- =========================================================
local resizeHandle = CreateFrame("Button", nil, frame)
frame.resizeHandle = resizeHandle
resizeHandle:SetSize(42, 42)
resizeHandle:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -6, 6)
resizeHandle:EnableMouse(true)

resizeHandle.tex = resizeHandle:CreateTexture(nil, "OVERLAY")
resizeHandle.tex:SetAllPoints()
resizeHandle.tex:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")

local function StopResize()
    if not frame.isResizing then return end

    frame.isResizing = false
    resizeHandle.tex:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")

    WowProfTrackerDB = WowProfTrackerDB or {}
    WowProfTrackerDB.scale = frame:GetScale()
end

resizeHandle:SetScript("OnEnter", function(self)
    if not frame.isResizing then
        self.tex:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    end
end)

resizeHandle:SetScript("OnLeave", function(self)
    if not frame.isResizing then
        self.tex:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    end
end)

resizeHandle:SetScript("OnMouseDown", function(self, button)
    if button ~= "LeftButton" then return end

    frame.isResizing = true
    self.tex:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")

    local cursorX = GetCursorPosition()
    local effectiveScale = UIParent:GetEffectiveScale()

    frame.resizeStartCursorX = cursorX / effectiveScale
    frame.resizeStartScale = frame:GetScale()
end)

resizeHandle:SetScript("OnMouseUp", function()
    StopResize()
end)

resizeHandle:SetScript("OnUpdate", function()
    if not frame.isResizing then return end

    if not IsMouseButtonDown("LeftButton") then
        StopResize()
        return
    end

    local cursorX = GetCursorPosition()
    local effectiveScale = UIParent:GetEffectiveScale()
    cursorX = cursorX / effectiveScale

    local deltaX = cursorX - (frame.resizeStartCursorX or cursorX)
    local newScale = (frame.resizeStartScale or DEFAULT_SCALE) + (deltaX / BASE_WIDTH)

    newScale = Clamp(newScale, MIN_SCALE, MAX_SCALE)
    frame:SetScale(newScale)
end)

-- =========================================================
-- UPDATE
-- =========================================================
function WowProfTracker_UpdateUI()
    local db = WowProfTrackerDB or {}
    local mats = db.mats or {}
    local bars = GetBarEstimate and GetBarEstimate() or {}
    local recipe = GetCurrentRecipe()
    local primaryMat, secondaryMat = GetPrimarySecondaryMats(recipe)

    frame.bsText:SetText(tostring(db.bs or 0))
    frame.minText:SetText(tostring(db.mining or 0))

    if recipe then
        frame.nextCraft:SetText(recipe.name)
        frame.nextRange:SetText("(" .. recipe.min .. "-" .. recipe.max .. ")")
    else
        frame.nextCraft:SetText("Done")
        frame.nextRange:SetText("")
    end

    if primaryMat then
        local available = GetAvailableCount(primaryMat.key)
        local needed = primaryMat.needed
        local pct = (needed > 0) and math.min(available / needed, 1) or 0

        frame.topMat1Label:SetText(materialLabels[primaryMat.key] or "")
        frame.topMat1Value:SetText(available .. " / " .. needed)

        SetBarColorByPercent(frame.healthBar, pct, "health")
        AnimateBar(frame.healthBar, pct)
        SetGlow(frame.healthBar.outerGlow, pct >= 1, 0.20, 1.00, 0.20, 0.20)
    else
        frame.topMat1Label:SetText("")
        frame.topMat1Value:SetText("")
        AnimateBar(frame.healthBar, 0)
        SetGlow(frame.healthBar.outerGlow, false)
    end

    if secondaryMat then
        local available = GetAvailableCount(secondaryMat.key)
        local needed = secondaryMat.needed
        local pct = (needed > 0) and math.min(available / needed, 1) or 0

        frame.topMat2Label:SetText(materialLabels[secondaryMat.key] or "")
        frame.topMat2Value:SetText(available .. " / " .. needed)
        frame.manaBar:Show()

        SetBarColorByPercent(frame.manaBar, pct, "mana")
        AnimateBar(frame.manaBar, pct)
        SetGlow(frame.manaBar.outerGlow, pct >= 1, 0.20, 1.00, 0.20, 0.20)
    else
        frame.topMat2Label:SetText("")
        frame.topMat2Value:SetText("")
        frame.manaBar:Hide()
        SetGlow(frame.manaBar.outerGlow, false)
    end

    frame.zoneText:SetText(GetZoneSuggestion and (GetZoneSuggestion() or "-") or "-")

    local barParts = {}
    if (bars.copperBars or 0) > GetMatCount("copperBars") then
        barParts[#barParts + 1] = "Copper: +" .. ((bars.copperBars or 0) - GetMatCount("copperBars"))
    end
    if (bars.tinBars or 0) > GetMatCount("tinBars") then
        barParts[#barParts + 1] = "Tin: +" .. ((bars.tinBars or 0) - GetMatCount("tinBars"))
    end
    if (bars.ironBars or 0) > GetMatCount("ironBars") then
        barParts[#barParts + 1] = "Iron: +" .. ((bars.ironBars or 0) - GetMatCount("ironBars"))
    end
    if (bars.mithrilBars or 0) > GetMatCount("mithrilBars") then
        barParts[#barParts + 1] = "Mithril: +" .. ((bars.mithrilBars or 0) - GetMatCount("mithrilBars"))
    end
    if (bars.thoriumBars or 0) > GetMatCount("thoriumBars") then
        barParts[#barParts + 1] = "Thorium: +" .. ((bars.thoriumBars or 0) - GetMatCount("thoriumBars"))
    end

    if #barParts == 0 then
        frame.barsFromOreText:SetText("None")
    else
        frame.barsFromOreText:SetText(table.concat(barParts, "   "))
    end

    local canCraft = GetMaxCraftable(recipe)
    frame.canCraftText:SetText(tostring(canCraft))
    if canCraft > 0 then
        frame.canCraftText:SetTextColor(0.30, 0.95, 0.30)
        SetPulse(frame.canCraftText, true)
        SetPulse(frame.nextCraft, true)
    else
        frame.canCraftText:SetTextColor(1.00, 0.20, 0.20)
        SetPulse(frame.canCraftText, false)
        SetPulse(frame.nextCraft, false)
    end

    frame.totalText:SetText(tostring(CountTotalMats()))

    for i, key in ipairs(leftMaterials) do
        local row = frame.leftRows[i]
        local v = mats[key] or 0

        row.label:SetText(materialLabels[key] or key)
        row.value:SetText(tostring(v))

        if v == 0 then
            row.value:SetTextColor(1.00, 0.20, 0.20)
        else
            row.value:SetTextColor(0.30, 0.95, 0.30)
        end
    end

    for i, key in ipairs(rightMaterials) do
        local row = frame.rightRows[i]
        local v = mats[key] or 0

        row.label:SetText(materialLabels[key] or key)
        row.value:SetText(tostring(v))

        if v == 0 then
            row.value:SetTextColor(1.00, 0.20, 0.20)
        else
            row.value:SetTextColor(0.30, 0.95, 0.30)
        end
    end

    if WowProfTrackerDB and WowProfTrackerDB.minimized then
        SetMinimized(true)
        frame:Show()
        return
    end

    if WowProfTrackerDB and WowProfTrackerDB.hidden then
        frame:Hide()
    else
        frame:Show()
    end
end

-- =========================================================
-- SHOW / HIDE / TOGGLE
-- =========================================================
function WowProfTracker_Show()
    WowProfTrackerDB = WowProfTrackerDB or {}
    WowProfTrackerDB.hidden = false
    frame:Show()

    if WowProfTrackerDB.minimized then
        SetMinimized(true)
    else
        WowProfTracker_UpdateUI()
    end
end

function WowProfTracker_Hide()
    WowProfTrackerDB = WowProfTrackerDB or {}
    WowProfTrackerDB.hidden = true
    frame:Hide()
end

function WowProfTracker_Toggle()
    if frame:IsShown() then
        WowProfTracker_Hide()
    else
        WowProfTracker_Show()
    end
end

if WowProfTrackerDB and WowProfTrackerDB.minimized then
    SetMinimized(true)
end

frame:Hide()