WowProfTrackerDB = WowProfTrackerDB or {}

local addon = CreateFrame("Frame", "WowProfTrackerEventFrame")

local trackedItems = {
    ["Copper Ore"] = "copperOre",
    ["Tin Ore"] = "tinOre",
    ["Silver Ore"] = "silverOre",
    ["Iron Ore"] = "ironOre",
    ["Gold Ore"] = "goldOre",
    ["Mithril Ore"] = "mithrilOre",
    ["Truesilver Ore"] = "truesilverOre",
    ["Thorium Ore"] = "thoriumOre",

    ["Copper Bar"] = "copperBars",
    ["Tin Bar"] = "tinBars",
    ["Bronze Bar"] = "bronzeBars",
    ["Iron Bar"] = "ironBars",
    ["Steel Bar"] = "steelBars",
    ["Mithril Bar"] = "mithrilBars",
    ["Thorium Bar"] = "thoriumBars",

    ["Rough Stone"] = "roughStone",
    ["Coarse Stone"] = "coarseStone",
    ["Heavy Stone"] = "heavyStone",
    ["Solid Stone"] = "solidStone",
    ["Dense Stone"] = "denseStone",
}

local function msg(text)
    DEFAULT_CHAT_FRAME:AddMessage("|cff4ea1ffWPT|r: " .. tostring(text))
end

local function initDB()
    WowProfTrackerDB = WowProfTrackerDB or {}
    WowProfTrackerDB.mats = WowProfTrackerDB.mats or {}
    WowProfTrackerDB.mining = WowProfTrackerDB.mining or 0
    WowProfTrackerDB.bs = WowProfTrackerDB.bs or 0
    WowProfTrackerDB.hidden = WowProfTrackerDB.hidden or false
end

local function GetBagNumSlotsCompat(bag)
    if C_Container and C_Container.GetContainerNumSlots then
        return C_Container.GetContainerNumSlots(bag)
    end

    if GetContainerNumSlots then
        return GetContainerNumSlots(bag)
    end

    return 0
end

local function GetBagItemIDCompat(bag, slot)
    if C_Container and C_Container.GetContainerItemID then
        return C_Container.GetContainerItemID(bag, slot)
    end

    if GetContainerItemID then
        return GetContainerItemID(bag, slot)
    end

    return nil
end

local function GetBagItemCountCompat(bag, slot)
    if C_Container and C_Container.GetContainerItemInfo then
        local info = C_Container.GetContainerItemInfo(bag, slot)
        if info then
            return info.stackCount or 0
        end
        return 0
    end

    if GetContainerItemInfo then
        local _, itemCount = GetContainerItemInfo(bag, slot)
        return itemCount or 0
    end

    return 0
end

function ScanBags()
    local counts = {}

    for bag = 0, 4 do
        local slots = GetBagNumSlotsCompat(bag)
        for slot = 1, slots do
            local itemID = GetBagItemIDCompat(bag, slot)
            if itemID then
                local itemName = GetItemInfo(itemID)
                local count = GetBagItemCountCompat(bag, slot)

                if itemName and trackedItems[itemName] then
                    local key = trackedItems[itemName]
                    counts[key] = (counts[key] or 0) + (count or 0)
                end
            end
        end
    end

    WowProfTrackerDB.mats = counts
end

local function UpdateSkillsFromProfessionsAPI()
    local foundMining = 0
    local foundBS = 0

    if not GetProfessions or not GetProfessionInfo then
        return foundMining, foundBS
    end

    local prof1, prof2, archaeology, fishing, cooking, firstAid = GetProfessions()
    local professions = { prof1, prof2, archaeology, fishing, cooking, firstAid }

    for _, profIndex in ipairs(professions) do
        if profIndex then
            local name, _, skillRank = GetProfessionInfo(profIndex)

            if name == "Mining" then
                foundMining = skillRank or 0
            elseif name == "Blacksmithing" then
                foundBS = skillRank or 0
            end
        end
    end

    return foundMining, foundBS
end

local function UpdateSkillsFromSkillLines()
    local foundMining = 0
    local foundBS = 0

    if not GetNumSkillLines or not GetSkillLineInfo then
        return foundMining, foundBS
    end

    local numLines = GetNumSkillLines()
    for i = 1, numLines do
        local skillName, isHeader, _, skillRank = GetSkillLineInfo(i)

        if not isHeader then
            if skillName == "Mining" then
                foundMining = skillRank or 0
            elseif skillName == "Blacksmithing" then
                foundBS = skillRank or 0
            end
        end
    end

    return foundMining, foundBS
end

function UpdateSkills()
    local mining = 0
    local bs = 0

    local apiMining, apiBS = UpdateSkillsFromProfessionsAPI()
    mining = apiMining or 0
    bs = apiBS or 0

    if mining == 0 or bs == 0 then
        local skillLineMining, skillLineBS = UpdateSkillsFromSkillLines()

        if mining == 0 and skillLineMining > 0 then
            mining = skillLineMining
        end

        if bs == 0 and skillLineBS > 0 then
            bs = skillLineBS
        end
    end

    WowProfTrackerDB.mining = mining
    WowProfTrackerDB.bs = bs
end

function GetRecommendation()
    local bs = WowProfTrackerDB.bs or 0

    if bs < 65 then return "Rough Grinding Stone"
    elseif bs < 75 then return "Coarse Sharpening Stone"
    elseif bs < 90 then return "Coarse Grinding Stone"
    elseif bs < 100 then return "Runed Copper Belt"
    elseif bs < 125 then return "Rough Bronze Leggings"
    elseif bs < 140 then return "Heavy Grinding Stone"
    elseif bs < 150 then return "Patterned Bronze Bracers"
    elseif bs < 165 then return "Green Iron Leggings"
    elseif bs < 190 then return "Green Iron Bracers"
    elseif bs < 200 then return "Golden Scale Bracers"
    elseif bs < 210 then return "Solid Grinding Stone"
    elseif bs < 225 then return "Heavy Mithril Gauntlet"
    elseif bs < 235 then return "Steel Plate Helm"
    elseif bs < 250 then return "Mithril Coif"
    elseif bs < 260 then return "Dense Sharpening Stone"
    elseif bs < 270 then return "Thorium Belt"
    elseif bs < 275 then return "Thorium Bracers"
    elseif bs < 290 then return "Imperial Plate Bracers"
    elseif bs < 300 then return "Thorium Boots"
    else return "Done"
    end
end

function GetBarEstimate()
    local mats = WowProfTrackerDB.mats or {}

    return {
        copperBars  = (mats.copperBars or 0)  + math.floor((mats.copperOre or 0) / 1),
        tinBars     = (mats.tinBars or 0)     + math.floor((mats.tinOre or 0) / 1),
        ironBars    = (mats.ironBars or 0)    + math.floor((mats.ironOre or 0) / 1),
        mithrilBars = (mats.mithrilBars or 0) + math.floor((mats.mithrilOre or 0) / 1),
        thoriumBars = (mats.thoriumBars or 0) + math.floor((mats.thoriumOre or 0) / 1),
    }
end

function GetZoneSuggestion()
    local m = WowProfTrackerDB.mining or 0

    if m < 125 then
        return "Redridge"
    elseif m < 175 then
        return "Arathi"
    elseif m < 245 then
        return "Tanaris"
    elseif m < 275 then
        return "Un'Goro"
    else
        return "EPL / Winterspring"
    end
end

function WowProfTracker_RefreshAll(showMessage)
    ScanBags()
    UpdateSkills()

    if WowProfTracker_UpdateUI then
        WowProfTracker_UpdateUI()
    end

    if showMessage then
        msg("Refreshed. Mining: " .. (WowProfTrackerDB.mining or 0) .. ", Blacksmithing: " .. (WowProfTrackerDB.bs or 0))
    end
end

SLASH_WPT1 = "/wpt"
SlashCmdList["WPT"] = function(msgText)
    local cmd = string.lower((msgText or ""):match("^%s*(.-)%s*$"))

    if cmd == "reset" then
        WowProfTrackerDB = nil
        initDB()
        WowProfTracker_RefreshAll(false)
        msg("Reset complete.")
        return
    end

    if cmd == "refresh" then
        WowProfTracker_RefreshAll(true)
        return
    end

    if cmd == "show" then
        if WowProfTracker_Show then
            WowProfTracker_Show()
        end
        return
    end

    if cmd == "hide" then
        if WowProfTracker_Hide then
            WowProfTracker_Hide()
        end
        return
    end

    if cmd == "toggle" or cmd == "" then
        if WowProfTracker_Toggle then
            WowProfTracker_Toggle()
        else
            msg("UI not ready.")
        end
        return
    end

    msg("Commands: /wpt, /wpt toggle, /wpt refresh, /wpt show, /wpt hide, /wpt reset")
end

addon:RegisterEvent("ADDON_LOADED")
addon:RegisterEvent("PLAYER_LOGIN")
addon:RegisterEvent("BAG_UPDATE_DELAYED")
addon:RegisterEvent("SKILL_LINES_CHANGED")
addon:RegisterEvent("TRADE_SKILL_SHOW")
addon:RegisterEvent("TRADE_SKILL_UPDATE")

addon:SetScript("OnEvent", function(_, event, arg1)
    if event == "ADDON_LOADED" then
        if arg1 ~= "WowProfTracker" then
            return
        end

        initDB()

    elseif event == "PLAYER_LOGIN" then
        WowProfTracker_RefreshAll(false)
        msg("Loaded. Type /wpt")

        if C_Timer and C_Timer.After then
            C_Timer.After(1, function()
                WowProfTracker_RefreshAll(false)
            end)

            C_Timer.After(3, function()
                WowProfTracker_RefreshAll(false)
            end)
        end

    elseif event == "BAG_UPDATE_DELAYED" then
        ScanBags()
        if WowProfTracker_UpdateUI then
            WowProfTracker_UpdateUI()
        end

    elseif event == "SKILL_LINES_CHANGED" or event == "TRADE_SKILL_SHOW" or event == "TRADE_SKILL_UPDATE" then
        UpdateSkills()
        if WowProfTracker_UpdateUI then
            WowProfTracker_UpdateUI()
        end
    end
end)