local frame = CreateFrame("Frame", "WOWLWT_Frame", UIParent)

-- =========================================================
-- BASE FRAME
-- =========================================================
local BASE_WIDTH = 1366
local BASE_HEIGHT = 1031
local DEFAULT_SCALE = 0.38
local MIN_SCALE = 0.22
local MAX_SCALE = 0.80

local LW_FULL_X,  LW_FULL_Y  = 210, -300
local CAN_FULL_X, CAN_FULL_Y = 420, -300

local LW_MIN_X,   LW_MIN_Y   = 195, -290
local CAN_MIN_X,  CAN_MIN_Y  = 412, -290

WowLWTrackerDB = WowLWTrackerDB or {}

frame:SetSize(BASE_WIDTH, BASE_HEIGHT)

local savedScale = WowLWTrackerDB.scale or DEFAULT_SCALE
if savedScale < MIN_SCALE then savedScale = MIN_SCALE end
if savedScale > MAX_SCALE then savedScale = MAX_SCALE end

frame:SetScale(savedScale)
frame:ClearAllPoints()
frame:SetPoint("TOPLEFT", UIParent, "TOPLEFT", 120, -120)

frame:SetMovable(true)
frame:EnableMouse(true)
frame:RegisterForDrag("LeftButton")
frame:SetClampedToScreen(true)

frame:SetScript("OnDragStart", function(self)
    if self.isResizing then return end
    self:StartMoving()
end)

frame:SetScript("OnDragStop", function(self)
    self:StopMovingOrSizing()

    WowLWTrackerDB = WowLWTrackerDB or {}
    local point, _, _, x, y = self:GetPoint()
    WowLWTrackerDB.pos = { point = point, x = x, y = y }
end)

if WowLWTrackerDB.pos then
    local p = WowLWTrackerDB.pos
    frame:ClearAllPoints()
    frame:SetPoint(p.point, UIParent, p.point, p.x, p.y)
end

frame.bg = frame:CreateTexture(nil, "BACKGROUND")
frame.bg:SetAllPoints()
frame.bg:SetTexture("Interface\\AddOns\\WowLWTracker\\Media\\UI.tga")

-- =========================================================
-- TEXT HELPERS
-- =========================================================
local function CreateText(size, r, g, b, justifyH)
    local t = frame:CreateFontString(nil, "OVERLAY")
    t:SetFont("Fonts\\FRIZQT__.TTF", size, "OUTLINE")
    t:SetTextColor(r or 1, g or 1, b or 1, 1)
    t:SetJustifyH(justifyH or "LEFT")
    t:SetJustifyV("MIDDLE")
    return t
end

-- =========================================================
-- TEXT REGIONS
-- =========================================================
frame.lwText = CreateText(46, 1.00, 0.82, 0.00, "CENTER")
frame.canText = CreateText(46, 0.30, 1.00, 0.30, "CENTER")

local function PositionSkillNumbers(minimized)
    frame.lwText:ClearAllPoints()
    frame.canText:ClearAllPoints()

    if minimized then
        frame.lwText:SetPoint("CENTER", frame, "TOPLEFT", LW_MIN_X, LW_MIN_Y)
        frame.canText:SetPoint("CENTER", frame, "TOPLEFT", CAN_MIN_X, CAN_MIN_Y)
    else
        frame.lwText:SetPoint("CENTER", frame, "TOPLEFT", LW_FULL_X, LW_FULL_Y)
        frame.canText:SetPoint("CENTER", frame, "TOPLEFT", CAN_FULL_X, CAN_FULL_Y)
    end
end

PositionSkillNumbers(false)

frame.nextText = CreateText(28, 1.00, 0.82, 0.00, "CENTER")
frame.nextText:SetPoint("CENTER", frame, "TOPLEFT", 935, -378)

frame.routeText = CreateText(22, 1, 1, 1)
frame.routeText:SetPoint("TOPLEFT", frame, "TOPLEFT", 142, -475)

frame.vendorText = CreateText(18, 1, 1, 1)
frame.vendorText:SetPoint("TOPLEFT", frame, "TOPLEFT", 482, -475)

frame.yieldText = CreateText(22, 1, 1, 1)
frame.yieldText:SetPoint("TOPLEFT", frame, "TOPLEFT", 820, -475)

frame.totalText = CreateText(22, 1, 1, 1)
frame.totalText:SetPoint("TOPLEFT", frame, "TOPLEFT", 1100, -475)

frame.commandText = CreateText(22, 0.96, 0.78, 0.20, "CENTER")
frame.commandText:SetPoint("CENTER", frame, "BOTTOM", 0, 38)
frame.commandText:SetText("/LWT TOGGLE   •   /LWT REFRESH   •   /LWT ROUTE")

-- =========================================================
-- GLOW
-- =========================================================
frame.hideGlow = frame:CreateTexture(nil, "ARTWORK", nil, 3)
frame.hideGlow:SetTexture("Interface\\Buttons\\WHITE8X8")
frame.hideGlow:SetBlendMode("ADD")
frame.hideGlow:SetColorTexture(0.25, 1.0, 0.25, 0.14)
frame.hideGlow:SetPoint("TOPLEFT", frame, "TOPLEFT", 145, -85)
frame.hideGlow:SetSize(260, 260)
frame.hideGlow:Hide()

-- =========================================================
-- MATERIAL ROWS
-- =========================================================
local leftMaterials = {
    "Light Leather",
    "Medium Leather",
    "Heavy Leather",
    "Thick Leather",
    "Rugged Leather",
    "Light Hide",
    "Medium Hide",
    "Heavy Hide",
    "Thick Hide",
    "Rugged Hide",
}

local rightMaterials = {
    "Cured Medium Hide",
    "Cured Heavy Hide",
    "Fine Leather Belt",
    "Coarse Thread",
    "Fine Thread",
    "Silken Thread",
    "Rune Thread",
    "Salt",
    "Gray Dye",
    "Black Dye",
}

local materialKeys = {
    ["Light Leather"] = "lightLeather",
    ["Medium Leather"] = "mediumLeather",
    ["Heavy Leather"] = "heavyLeather",
    ["Thick Leather"] = "thickLeather",
    ["Rugged Leather"] = "ruggedLeather",
    ["Light Hide"] = "lightHide",
    ["Medium Hide"] = "mediumHide",
    ["Heavy Hide"] = "heavyHide",
    ["Thick Hide"] = "thickHide",
    ["Rugged Hide"] = "ruggedHide",

    ["Cured Medium Hide"] = "curedMediumHide",
    ["Cured Heavy Hide"] = "curedHeavyHide",
    ["Fine Leather Belt"] = "fineLeatherBelt",
    ["Coarse Thread"] = "coarseThread",
    ["Fine Thread"] = "fineThread",
    ["Silken Thread"] = "silkenThread",
    ["Rune Thread"] = "runeThread",
    ["Salt"] = "salt",
    ["Gray Dye"] = "grayDye",
    ["Black Dye"] = "blackDye",
}

frame.leftRows = {}
frame.rightRows = {}

local function CreateMatRow(xLabel, xValue, y)
    local label = CreateText(18, 1, 1, 1)
    label:SetPoint("TOPLEFT", frame, "TOPLEFT", xLabel, y)

    local value = CreateText(18, 0.30, 0.95, 0.30, "RIGHT")
    value:SetPoint("TOPLEFT", frame, "TOPLEFT", xValue, y)

    return { label = label, value = value }
end

local yStartLeft = -575
for i = 1, #leftMaterials do
    frame.leftRows[i] = CreateMatRow(135, 515, yStartLeft - ((i - 1) * 35))
end

local yStartRight = -575
for i = 1, #rightMaterials do
    frame.rightRows[i] = CreateMatRow(775, 1220, yStartRight - ((i - 1) * 37))
end

-- =========================================================
-- VISIBILITY HELPERS
-- =========================================================
local function SetRegionVisible(region, visible)
    if not region then return end
    if visible then region:Show() else region:Hide() end
end

local function SetChildrenVisible(visible)
    local children = {
        frame.nextText,
        frame.routeText,
        frame.vendorText,
        frame.yieldText,
        frame.totalText,
        frame.commandText,
        frame.refreshButton,
        frame.resizeHandle,
    }

    for _, child in ipairs(children) do
        SetRegionVisible(child, visible)
    end

    if frame.leftRows then
        for _, row in ipairs(frame.leftRows) do
            SetRegionVisible(row.label, visible)
            SetRegionVisible(row.value, visible)
        end
    end

    if frame.rightRows then
        for _, row in ipairs(frame.rightRows) do
            SetRegionVisible(row.label, visible)
            SetRegionVisible(row.value, visible)
        end
    end
end

local function SetMinimized(minimized)
    WowLWTrackerDB = WowLWTrackerDB or {}
    WowLWTrackerDB.minimized = minimized and true or false

    if minimized then
        frame:SetSize(500, 430)
        frame.bg:SetTexCoord(0.00, 0.38, 0.00, 0.43)
        PositionSkillNumbers(true)

        SetChildrenVisible(false)

        frame.lwText:Show()
        frame.canText:Show()

        if frame.closeButton then frame.closeButton:Hide() end
        if frame.minimizedClickButton then frame.minimizedClickButton:Show() end
    else
        frame:SetSize(BASE_WIDTH, BASE_HEIGHT)
        frame.bg:SetTexCoord(0, 1, 0, 1)
        PositionSkillNumbers(false)

        if frame.minimizedClickButton then frame.minimizedClickButton:Hide() end
        if frame.closeButton then frame.closeButton:Show() end

        SetChildrenVisible(true)

        if WowLW_UpdateUI then
            WowLW_UpdateUI()
        end
    end
end

-- =========================================================
-- BUTTON HOTSPOTS
-- =========================================================
frame.refreshButton = CreateFrame("Button", nil, frame)
frame.refreshButton:SetSize(140, 50)
frame.refreshButton:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -70, -130)
frame.refreshButton:SetScript("OnClick", function()
    if WowLW_Refresh then
        WowLW_Refresh()
    end
end)

frame.closeButton = CreateFrame("Button", nil, frame)
frame.closeButton:SetSize(90, 90)
frame.closeButton:SetPoint("TOPRIGHT", frame, "TOPRIGHT", -65, -88)
frame.closeButton:SetScript("OnClick", function()
    SetMinimized(not (WowLWTrackerDB and WowLWTrackerDB.minimized))
end)

frame.minimizedClickButton = CreateFrame("Button", nil, frame)
frame.minimizedClickButton:SetAllPoints(frame)
frame.minimizedClickButton:SetScript("OnClick", function()
    if WowLWTrackerDB and WowLWTrackerDB.minimized then
        SetMinimized(false)
    end
end)
frame.minimizedClickButton:Hide()

-- =========================================================
-- RESIZE HANDLE
-- =========================================================
local resizeHandle = CreateFrame("Button", nil, frame)
frame.resizeHandle = resizeHandle
resizeHandle:SetSize(42, 42)
resizeHandle:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", -6, 6)
resizeHandle:EnableMouse(true)

resizeHandle.tex = resizeHandle:CreateTexture(nil, "OVERLAY")
resizeHandle.tex:SetAllPoints()
resizeHandle.tex:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")

local function StopResize()
    if not frame.isResizing then return end

    frame.isResizing = false
    resizeHandle.tex:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")

    WowLWTrackerDB = WowLWTrackerDB or {}
    WowLWTrackerDB.scale = frame:GetScale()
end

resizeHandle:SetScript("OnEnter", function(self)
    if not frame.isResizing then
        self.tex:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    end
end)

resizeHandle:SetScript("OnLeave", function(self)
    if not frame.isResizing then
        self.tex:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    end
end)

resizeHandle:SetScript("OnMouseDown", function(self, button)
    if button ~= "LeftButton" then return end

    frame.isResizing = true
    self.tex:SetTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")

    local cursorX = GetCursorPosition()
    local effectiveScale = UIParent:GetEffectiveScale()

    frame.resizeStartCursorX = cursorX / effectiveScale
    frame.resizeStartScale = frame:GetScale()
end)

resizeHandle:SetScript("OnMouseUp", function()
    StopResize()
end)

resizeHandle:SetScript("OnUpdate", function()
    if not frame.isResizing then return end

    if not IsMouseButtonDown("LeftButton") then
        StopResize()
        return
    end

    local cursorX = GetCursorPosition()
    local effectiveScale = UIParent:GetEffectiveScale()
    cursorX = cursorX / effectiveScale

    local deltaX = cursorX - (frame.resizeStartCursorX or cursorX)
    local newScale = (frame.resizeStartScale or DEFAULT_SCALE) + (deltaX / BASE_WIDTH)

    newScale = Clamp(newScale, MIN_SCALE, MAX_SCALE)
    frame:SetScale(newScale)
end)

-- =========================================================
-- UI UPDATE
-- =========================================================
local function GetMatCount(key)
    local mats = WowLWTrackerDB and WowLWTrackerDB.mats or {}
    return mats[key] or 0
end

local function CountTrackedMats()
    local mats = WowLWTrackerDB and WowLWTrackerDB.mats or {}
    local total = 0

    for _, v in pairs(mats) do
        total = total + (v or 0)
    end

    return total
end

function WowLW_UpdateUI()
    local recipe = WowLW_GetRecipe and WowLW_GetRecipe() or nil
    local can = WowLW_GetCanCraft and WowLW_GetCanCraft(recipe) or 0

    frame.lwText:SetText(tostring((WowLWTrackerDB and WowLWTrackerDB.lw) or 0))
    frame.canText:SetText(tostring(can or 0))

    if recipe then
        frame.nextText:SetText(recipe.name or recipe[3] or "Done")
    else
        frame.nextText:SetText("Done")
    end

    if WowLW_GetBestZone then
        frame.routeText:SetText(WowLW_GetBestZone())
    elseif WowLW_GetBestRoute then
        frame.routeText:SetText(WowLW_GetBestRoute())
    else
        frame.routeText:SetText("-")
    end

    if WowLW_GetVendorText then
        frame.vendorText:SetText(WowLW_GetVendorText(recipe))
    else
        frame.vendorText:SetText("Vendor: /lwt vendor")
    end

    if WowLW_GetYield then
        frame.yieldText:SetText(tostring(WowLW_GetYield()))
    else
        frame.yieldText:SetText("0")
    end

    frame.totalText:SetText(tostring(CountTrackedMats()))

    for i, name in ipairs(leftMaterials) do
        local row = frame.leftRows[i]
        local key = materialKeys[name]
        local v = GetMatCount(key)

        row.label:SetText(name)
        row.value:SetText(tostring(v))

        if v == 0 then
            row.value:SetTextColor(1, 0.20, 0.20)
        else
            row.value:SetTextColor(0.30, 0.95, 0.30)
        end
    end

    for i, name in ipairs(rightMaterials) do
        local row = frame.rightRows[i]
        local key = materialKeys[name]
        local v = GetMatCount(key)

        row.label:SetText(name)
        row.value:SetText(tostring(v))

        if v == 0 then
            row.value:SetTextColor(1, 0.20, 0.20)
        else
            row.value:SetTextColor(0.30, 0.95, 0.30)
        end
    end

    if can and can > 0 then
        frame.hideGlow:Show()
    else
        frame.hideGlow:Hide()
    end

    if WowLWTrackerDB and WowLWTrackerDB.minimized then
        SetMinimized(true)
        frame:Show()
        return
    end

    if WowLWTrackerDB and WowLWTrackerDB.hidden then
        frame:Hide()
    else
        frame:Show()
    end
end

-- =========================================================
-- SHOW / HIDE / TOGGLE
-- =========================================================
function WowLW_Show()
    WowLWTrackerDB = WowLWTrackerDB or {}
    WowLWTrackerDB.hidden = false
    frame:Show()

    if WowLWTrackerDB.minimized then
        SetMinimized(true)
    else
        WowLW_UpdateUI()
    end
end

function WowLW_Hide()
    WowLWTrackerDB = WowLWTrackerDB or {}
    WowLWTrackerDB.hidden = true
    frame:Hide()
end

function WowLW_Toggle()
    if frame:IsShown() then
        WowLW_Hide()
    else
        WowLW_Show()
    end
end

if WowLWTrackerDB and WowLWTrackerDB.minimized then
    SetMinimized(true)
end

frame:Hide()