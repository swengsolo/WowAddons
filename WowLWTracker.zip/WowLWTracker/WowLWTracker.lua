WowLWTrackerDB = WowLWTrackerDB or {}

local addon = CreateFrame("Frame", "WowLWTrackerEventFrame")

-- =========================================================
-- DEFAULT DB
-- =========================================================
local function InitDB()
    WowLWTrackerDB = WowLWTrackerDB or {}
    WowLWTrackerDB.lw = WowLWTrackerDB.lw or 0
    WowLWTrackerDB.mats = WowLWTrackerDB.mats or {}

    WowLWTrackerDB.stats = WowLWTrackerDB.stats or {}
    WowLWTrackerDB.stats.kills = WowLWTrackerDB.stats.kills or 0
    WowLWTrackerDB.stats.leather = WowLWTrackerDB.stats.leather or 0
    WowLWTrackerDB.stats.lastLeather = WowLWTrackerDB.stats.lastLeather or 0

    WowLWTrackerDB.route = WowLWTrackerDB.route or {}
    WowLWTrackerDB.route.index = WowLWTrackerDB.route.index or 1
    WowLWTrackerDB.route.history = WowLWTrackerDB.route.history or {}
end

local function Msg(text)
    DEFAULT_CHAT_FRAME:AddMessage("|cffb88a4aLWT|r: " .. tostring(text))
end

-- =========================================================
-- TRACKED ITEMS
-- =========================================================
local tracked = {
    ["Ruined Leather Scraps"] = "ruinedLeatherScraps",

    ["Light Leather"] = "lightLeather",
    ["Light Hide"] = "lightHide",

    ["Medium Leather"] = "mediumLeather",
    ["Medium Hide"] = "mediumHide",

    ["Heavy Leather"] = "heavyLeather",
    ["Heavy Hide"] = "heavyHide",

    ["Thick Leather"] = "thickLeather",
    ["Thick Hide"] = "thickHide",

    ["Rugged Leather"] = "ruggedLeather",
    ["Rugged Hide"] = "ruggedHide",

    ["Cured Medium Hide"] = "curedMediumHide",
    ["Cured Heavy Hide"] = "curedHeavyHide",
    ["Fine Leather Belt"] = "fineLeatherBelt",

    ["Coarse Thread"] = "coarseThread",
    ["Fine Thread"] = "fineThread",
    ["Silken Thread"] = "silkenThread",
    ["Rune Thread"] = "runeThread",

    ["Salt"] = "salt",
    ["Gray Dye"] = "grayDye",
    ["Black Dye"] = "blackDye",
}

-- =========================================================
-- RECIPES 1-300
-- =========================================================
local recipes = {
    { min = 1,   max = 35,  name = "Light Armor Kit",              mats = { lightLeather = 1 } },
    { min = 35,  max = 55,  name = "Embossed Leather Gloves",      mats = { lightLeather = 3, coarseThread = 2 } },
    { min = 55,  max = 85,  name = "Embossed Leather Boots",       mats = { lightLeather = 8, coarseThread = 5 } },
    { min = 85,  max = 100, name = "Fine Leather Belt",            mats = { lightLeather = 6, coarseThread = 2 } },

    { min = 100, max = 115, name = "Cured Medium Hide",            mats = { mediumHide = 1, salt = 1 } },
    { min = 115, max = 130, name = "Dark Leather Boots",           mats = { mediumLeather = 4, fineThread = 2, grayDye = 1 } },
    { min = 130, max = 145, name = "Dark Leather Belt",            mats = { fineLeatherBelt = 1, curedMediumHide = 1, fineThread = 2, grayDye = 1 } },
    { min = 145, max = 150, name = "Hillman's Leather Gloves",     mats = { mediumLeather = 14, fineThread = 4 } },

    { min = 150, max = 160, name = "Cured Heavy Hide",             mats = { heavyHide = 1, salt = 3 } },
    { min = 160, max = 170, name = "Heavy Armor Kit",              mats = { heavyLeather = 5, fineThread = 1 } },
    { min = 170, max = 180, name = "Dusky Leather Leggings",       mats = { heavyLeather = 10, fineThread = 1, blackDye = 1 } },
    { min = 180, max = 195, name = "Barbaric Shoulders",           mats = { heavyLeather = 8, curedHeavyHide = 1, fineThread = 2 } },
    { min = 195, max = 205, name = "Dusky Bracers",                mats = { heavyLeather = 16, silkenThread = 2, blackDye = 1 } },

    { min = 205, max = 230, name = "Nightscape Headband",          mats = { thickLeather = 5, silkenThread = 2 } },
    { min = 230, max = 250, name = "Nightscape Pants",             mats = { thickLeather = 14, silkenThread = 4 } },
    { min = 250, max = 260, name = "Nightscape Boots",             mats = { thickLeather = 16, silkenThread = 2 } },

    { min = 260, max = 270, name = "Wicked Leather Gauntlets",     mats = { ruggedLeather = 8, blackDye = 1, runeThread = 1 } },
    { min = 270, max = 285, name = "Wicked Leather Bracers",       mats = { ruggedLeather = 8, blackDye = 1, runeThread = 1 } },
    { min = 285, max = 300, name = "Wicked Leather Headband",      mats = { ruggedLeather = 12, blackDye = 1, runeThread = 1 } },
}

-- =========================================================
-- ROUTES
-- =========================================================
local routes = {
    Westfall = {
        { x = 0.44, y = 0.68 },
        { x = 0.48, y = 0.62 },
        { x = 0.52, y = 0.65 },
        { x = 0.50, y = 0.72 },
    },
    Duskwood = {
        { x = 0.22, y = 0.44 },
        { x = 0.30, y = 0.52 },
        { x = 0.42, y = 0.60 },
        { x = 0.34, y = 0.70 },
    },
    STV = {
        { x = 0.32, y = 0.45 },
        { x = 0.35, y = 0.50 },
        { x = 0.38, y = 0.47 },
        { x = 0.34, y = 0.42 },
    },
    Feralas = {
        { x = 0.55, y = 0.60 },
        { x = 0.58, y = 0.63 },
        { x = 0.60, y = 0.58 },
        { x = 0.57, y = 0.55 },
    },
    UnGoro = {
        { x = 0.45, y = 0.55 },
        { x = 0.48, y = 0.60 },
        { x = 0.52, y = 0.58 },
        { x = 0.50, y = 0.52 },
    },
}

-- =========================================================
-- BAG API COMPATIBILITY - TBC ANNIVERSARY SAFE
-- =========================================================
local function GetBagNumSlotsCompat(bag)
    if C_Container and C_Container.GetContainerNumSlots then
        return C_Container.GetContainerNumSlots(bag)
    end

    if GetContainerNumSlots then
        return GetContainerNumSlots(bag)
    end

    return 0
end

local function GetBagItemIDCompat(bag, slot)
    if C_Container and C_Container.GetContainerItemID then
        return C_Container.GetContainerItemID(bag, slot)
    end

    if GetContainerItemID then
        return GetContainerItemID(bag, slot)
    end

    return nil
end

local function GetBagItemCountCompat(bag, slot)
    if C_Container and C_Container.GetContainerItemInfo then
        local info = C_Container.GetContainerItemInfo(bag, slot)
        if info then
            return info.stackCount or 0
        end
        return 0
    end

    if GetContainerItemInfo then
        local _, itemCount = GetContainerItemInfo(bag, slot)
        return itemCount or 0
    end

    return 0
end

-- =========================================================
-- SCANNING
-- =========================================================
local function ScanLeatherworking()
    WowLWTrackerDB.lw = 0

    if GetProfessions and GetProfessionInfo then
        local prof1, prof2, archaeology, fishing, cooking, firstAid = GetProfessions()
        local profs = { prof1, prof2, archaeology, fishing, cooking, firstAid }

        for _, profIndex in ipairs(profs) do
            if profIndex then
                local name, _, skillRank = GetProfessionInfo(profIndex)
                if name == "Leatherworking" then
                    WowLWTrackerDB.lw = skillRank or 0
                    return
                end
            end
        end
    end

    if GetNumSkillLines and GetSkillLineInfo then
        for i = 1, GetNumSkillLines() do
            local name, isHeader, _, rank = GetSkillLineInfo(i)
            if not isHeader and name == "Leatherworking" then
                WowLWTrackerDB.lw = rank or 0
                return
            end
        end
    end
end

local function ScanBags()
    WowLWTrackerDB.mats = {}

    for bag = 0, 4 do
        local slots = GetBagNumSlotsCompat(bag)

        for slot = 1, slots do
            local itemID = GetBagItemIDCompat(bag, slot)

            if itemID then
                local itemName = GetItemInfo(itemID)
                local key = tracked[itemName]

                if key then
                    local count = GetBagItemCountCompat(bag, slot)
                    WowLWTrackerDB.mats[key] = (WowLWTrackerDB.mats[key] or 0) + count
                end
            end
        end
    end
end

local function GetTotalLeather()
    local m = WowLWTrackerDB.mats or {}

    return (m.ruinedLeatherScraps or 0)
        + (m.lightLeather or 0)
        + (m.mediumLeather or 0)
        + (m.heavyLeather or 0)
        + (m.thickLeather or 0)
        + (m.ruggedLeather or 0)
end

-- =========================================================
-- RECIPE HELPERS
-- =========================================================
function WowLW_GetRecipe()
    local lw = WowLWTrackerDB.lw or 0

    if lw <= 0 then
        return recipes[1]
    end

    for _, recipe in ipairs(recipes) do
        if lw >= recipe.min and lw < recipe.max then
            return recipe
        end
    end

    return nil
end

function WowLW_GetCanCraft(recipe)
    if not recipe then return 0 end

    local maxCrafts = nil

    for mat, needed in pairs(recipe.mats) do
        local have = (WowLWTrackerDB.mats and WowLWTrackerDB.mats[mat]) or 0
        local canMake = math.floor(have / needed)

        if maxCrafts == nil or canMake < maxCrafts then
            maxCrafts = canMake
        end
    end

    return maxCrafts or 0
end

function WowLW_GetMissingMats(recipe)
    local missing = {}

    if not recipe then
        return missing
    end

    for mat, needed in pairs(recipe.mats) do
        local have = (WowLWTrackerDB.mats and WowLWTrackerDB.mats[mat]) or 0
        if have < needed then
            missing[mat] = needed - have
        end
    end

    return missing
end

function WowLW_GetRecipeName()
    local recipe = WowLW_GetRecipe()
    return recipe and recipe.name or "Done"
end

-- =========================================================
-- VENDOR / FARMING / ROUTING
-- =========================================================
local vendorItems = {
    coarseThread = true,
    fineThread = true,
    silkenThread = true,
    runeThread = true,
    salt = true,
    grayDye = true,
    blackDye = true,
}

local materialNames = {
    ruinedLeatherScraps = "Ruined Leather Scraps",
    lightLeather = "Light Leather",
    lightHide = "Light Hide",
    mediumLeather = "Medium Leather",
    mediumHide = "Medium Hide",
    heavyLeather = "Heavy Leather",
    heavyHide = "Heavy Hide",
    thickLeather = "Thick Leather",
    thickHide = "Thick Hide",
    ruggedLeather = "Rugged Leather",
    ruggedHide = "Rugged Hide",
    curedMediumHide = "Cured Medium Hide",
    curedHeavyHide = "Cured Heavy Hide",
    fineLeatherBelt = "Fine Leather Belt",
    coarseThread = "Coarse Thread",
    fineThread = "Fine Thread",
    silkenThread = "Silken Thread",
    runeThread = "Rune Thread",
    salt = "Salt",
    grayDye = "Gray Dye",
    blackDye = "Black Dye",
}

function WowLW_GetVendorNeeds(recipe)
    local needs = {}
    local missing = WowLW_GetMissingMats(recipe)

    for mat, amount in pairs(missing) do
        if vendorItems[mat] then
            needs[mat] = amount
        end
    end

    return needs
end

function WowLW_GetVendorText(recipe)
    local needs = WowLW_GetVendorNeeds(recipe)
    local parts = {}

    for mat, amount in pairs(needs) do
        parts[#parts + 1] = (materialNames[mat] or mat) .. " x" .. amount
    end

    if #parts == 0 then
        return "No vendor mats"
    end

    return table.concat(parts, ", ")
end

function WowLW_GetVendorLocation()
    local zone = GetRealZoneText and GetRealZoneText() or ""

    if zone == "Stormwind City" or zone == "Elwynn Forest" or zone == "Westfall" or zone == "Redridge Mountains" or zone == "Duskwood" then
        return "Stormwind Old Town"
    elseif zone == "Ironforge" or zone == "Dun Morogh" or zone == "Loch Modan" or zone == "Wetlands" then
        return "Ironforge Commons"
    elseif zone == "Darnassus" or zone == "Teldrassil" or zone == "Darkshore" or zone == "Ashenvale" then
        return "Darnassus Craftsmen's Terrace"
    elseif zone == "Stranglethorn Vale" then
        return "Booty Bay"
    end

    return "Nearest LW supplies vendor"
end

function WowLW_GetBestRoute()
    local lw = WowLWTrackerDB.lw or 0

    if lw < 100 then
        return "Westfall"
    elseif lw < 150 then
        return "Duskwood"
    elseif lw < 205 then
        return "STV"
    elseif lw < 250 then
        return "Feralas"
    end

    return "UnGoro"
end

function WowLW_GetBestZone()
    local route = WowLW_GetBestRoute()

    if route == "STV" then return "Stranglethorn Vale" end
    if route == "UnGoro" then return "Un'Goro Crater" end

    return route
end

function WowLW_NextWaypoint()
    local routeName = WowLW_GetBestRoute()
    local path = routes[routeName]

    if not path or #path == 0 then
        return nil, routeName
    end

    local route = WowLWTrackerDB.route
    route.index = route.index or 1

    local index = route.index
    local point = path[index]

    local historyScore = route.history[index] or 1
    if historyScore < 0.3 then
        index = index + 1
        if index > #path then index = 1 end
        point = path[index]
    end

    route.index = index + 1
    if route.index > #path then
        route.index = 1
    end

    return point, routeName
end

function WowLW_StartRoute()
    if not TomTom then
        Msg("TomTom is not installed. Best route: " .. WowLW_GetBestZone())
        return
    end

    if WowLWTrackerDB.routeTicker then
        Msg("Route already running.")
        return
    end

    WowLWTrackerDB.routeTicker = true

    C_Timer.NewTicker(8, function()
        local point, routeName = WowLW_NextWaypoint()

        if point then
            TomTom:AddWaypoint(0, point.x, point.y, { title = "LW Route - " .. tostring(routeName) })
        end
    end)

    Msg("Route started.")
end

function WowLW_StopRoute()
    WowLWTrackerDB.routeTicker = nil
    Msg("Route stop requested. Reload UI if an old ticker keeps running.")
end

function WowLW_SetVendorWaypoint()
    if not TomTom then
        Msg("TomTom is not installed. Vendor: " .. WowLW_GetVendorLocation())
        return
    end

    Msg("Vendor waypoint support needs zone-specific map IDs. Vendor: " .. WowLW_GetVendorLocation())
end

-- =========================================================
-- YIELD / SKINNING TRACKER
-- =========================================================
function WowLW_GetYield()
    local s = WowLWTrackerDB.stats or {}
    local kills = s.kills or 0

    if kills <= 0 then
        return 0
    end

    return math.floor(((s.leather or 0) / kills) * 100) / 100
end

function WowLW_ResetStats()
    WowLWTrackerDB.stats = {
        kills = 0,
        leather = 0,
        lastLeather = GetTotalLeather(),
    }

    Msg("Skinning stats reset.")
end

-- =========================================================
-- REFRESH
-- =========================================================
function WowLW_Refresh()
    InitDB()
    ScanLeatherworking()
    ScanBags()

    local total = GetTotalLeather()
    local s = WowLWTrackerDB.stats

    local diff = total - (s.lastLeather or 0)
    if diff > 0 then
        s.leather = (s.leather or 0) + diff
    end

    s.lastLeather = total

    if WowLW_UpdateUI then
        WowLW_UpdateUI()
    end
end

-- =========================================================
-- EVENTS
-- =========================================================
addon:RegisterEvent("ADDON_LOADED")
addon:RegisterEvent("PLAYER_LOGIN")
addon:RegisterEvent("BAG_UPDATE_DELAYED")
addon:RegisterEvent("SKILL_LINES_CHANGED")
addon:RegisterEvent("TRADE_SKILL_SHOW")
addon:RegisterEvent("TRADE_SKILL_UPDATE")
addon:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")

addon:SetScript("OnEvent", function(_, event, arg1)
    if event == "ADDON_LOADED" then
        if arg1 ~= "WowLWTracker" then return end
        InitDB()

    elseif event == "PLAYER_LOGIN" then
        WowLW_Refresh()
        Msg("Loaded. Type /lwt")

        if C_Timer and C_Timer.After then
            C_Timer.After(1, WowLW_Refresh)
            C_Timer.After(3, WowLW_Refresh)
        end

    elseif event == "BAG_UPDATE_DELAYED" then
        WowLW_Refresh()

    elseif event == "SKILL_LINES_CHANGED" or event == "TRADE_SKILL_SHOW" or event == "TRADE_SKILL_UPDATE" then
        WowLW_Refresh()

    elseif event == "COMBAT_LOG_EVENT_UNFILTERED" then
        local _, subevent, _, sourceGUID = CombatLogGetCurrentEventInfo()
        if subevent == "PARTY_KILL" and sourceGUID == UnitGUID("player") then
            InitDB()
            WowLWTrackerDB.stats.kills = (WowLWTrackerDB.stats.kills or 0) + 1
        end
    end
end)

-- =========================================================
-- SLASH COMMANDS
-- =========================================================
SLASH_WOWLW1 = "/lwt"
SlashCmdList["WOWLW"] = function(msg)
    msg = string.lower((msg or ""):match("^%s*(.-)%s*$"))

    if msg == "refresh" then
        WowLW_Refresh()
        Msg("Refreshed. LW: " .. tostring(WowLWTrackerDB.lw or 0))

    elseif msg == "toggle" or msg == "" then
        if WowLW_Toggle then
            WowLW_Toggle()
        end

    elseif msg == "route" then
        WowLW_StartRoute()

    elseif msg == "stoproute" then
        WowLW_StopRoute()

    elseif msg == "vendor" then
        WowLW_SetVendorWaypoint()

    elseif msg == "stats" then
        Msg("Kills: " .. tostring(WowLWTrackerDB.stats.kills or 0))
        Msg("Leather gained: " .. tostring(WowLWTrackerDB.stats.leather or 0))
        Msg("Yield: " .. tostring(WowLW_GetYield()) .. " leather/mob")

    elseif msg == "resetstats" then
        WowLW_ResetStats()
        if WowLW_UpdateUI then WowLW_UpdateUI() end

    else
        Msg("Commands: /lwt, /lwt refresh, /lwt route, /lwt stoproute, /lwt vendor, /lwt stats, /lwt resetstats")
    end
end